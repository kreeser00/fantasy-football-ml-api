class PredictionLevelException(Exception):
    
    def __init__(self, message):
        super(PredictionLevelException, self).__init__(message)
