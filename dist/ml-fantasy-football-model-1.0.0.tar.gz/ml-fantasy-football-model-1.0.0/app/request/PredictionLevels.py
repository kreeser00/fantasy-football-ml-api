from enum import Enum


class PredictionLevels(Enum):
    ROW = "ROW"
    ALL = "ALL"
