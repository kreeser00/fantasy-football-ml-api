class ModelConstants:
    PREDICTIONRESULTS = "PredictionResults"
    RESULTS = "Results"
    PREDICTIONS = "Predictions"
    DEVICE_VERSION = "DeviceVersion"
    MODEL_NAME_BTU = "BTU"
