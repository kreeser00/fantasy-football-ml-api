offerings_name = 'ffootball'
model_name = 'players'
device_serialized_object_mapping = '{"qb":"qb_prime_age_model.pkl"}'
