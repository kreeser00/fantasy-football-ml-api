from enum import Enum


class SerializedFileFormats(Enum):
    PICKLE = "pkl"
    HDF5 = "h5"
